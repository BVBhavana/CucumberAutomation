package stepDefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GoogleSearch {
	
	WebDriver wd ;
	
	@Given("I go to Google.com")
	public void i_go_to_google_com() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "C:\\Projects\\Practise_Project\\Automation\\chromedriver.exe" );
		wd = new ChromeDriver();
		//Navigate google
		wd.get("https://www.google.com/");
		Thread.sleep(5000);
		wd.manage().window().maximize();
	}

	@When("I search for the {string} in google")
	public void i_search_for_the_in_google(String searchText) {
	    // Write code here that turns the phrase above into concrete actions
		wd.findElement(By.xpath("//input[@title='Search']")).sendKeys(searchText +Keys.ENTER);
	}

	@Then("I click on the first link")
	public void i_click_on_the_first_link() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		List<WebElement> listOfLinks =wd.findElements(By.xpath("//a/h3"));
		listOfLinks.get(0).click();
		Thread.sleep(5000);
		wd.close();
	}

}
