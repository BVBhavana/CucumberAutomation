package TestNGtests;

import org.testng.annotations.Test;

public class FirstTestNG {
	
@Test
	public void firstTestMethod() {
	
	System.out.println("Hello");
	
}

}
