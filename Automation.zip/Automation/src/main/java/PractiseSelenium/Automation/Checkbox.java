package PractiseSelenium.Automation;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Checkbox {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Projects\\Practise_Project\\Automation\\chromedriver.exe" );
		WebDriver wd = new ChromeDriver();
		//Navigate google
		wd.get("https://demos.jquerymobile.com/1.4.5/checkboxradio-checkbox/");
		Thread.sleep(5000);
		List<WebElement> radiotwoElents =wd.findElements(By.xpath("label[text()='Two']"));
		 for(WebElement eachElement:radiotwoElents) {
				System.out.println(eachElement.getText());
				System.out.println(eachElement.isEnabled());
//				listLinks.get(i).getAttribute("class")
			}

	}

}
