package PractiseSelenium.Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SwitchIframe {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver",
				"C:\\\\Projects\\\\Practise_Project\\\\Automation\\\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		wd.manage().window().maximize();
		// Navigating to google
		wd.get("https://www.globalsqa.com/demo-site/frames-and-windows/#iFrame");
		Thread.sleep(5000);
		wd.switchTo().frame("globalSqa");
		wd.findElement(By.partialLinkText("Home")).click();
		Thread.sleep(5000);
		wd.close();
		
	}

	

}
