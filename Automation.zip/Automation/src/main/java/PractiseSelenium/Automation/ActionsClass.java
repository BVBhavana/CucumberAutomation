package PractiseSelenium.Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ActionsClass {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Projects\\Practise_Project\\Automation\\chromedriver.exe" );
		WebDriver wd = new ChromeDriver();
		wd.manage().window().maximize();
		Thread.sleep(2000);
		// Navigating to URL
		wd.get("https://www.google.com/");
		Thread.sleep(2000);
		WebElement inputSerachBox = wd.findElement(By.name("q"));
		Actions action=new  Actions(wd);
		action.keyDown(inputSerachBox,Keys.SHIFT);
		action.sendKeys(inputSerachBox,"SELenium");
		action.keyUp(inputSerachBox,Keys.SHIFT);
		action.doubleClick();
	//	action.keyDown(inputSerachBox,Keys.CONTROL)
		action.build().perform();
        //Double click
        //CTRL+C
        
		Thread.sleep(2000);
		wd.close();
	}

	
}
