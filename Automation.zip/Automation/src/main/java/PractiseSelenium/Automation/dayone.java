package PractiseSelenium.Automation;

import java.util.List;



import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class dayone {
	
//	private static List<WebElement> WebElement;

	public static void main(String[]args) throws InterruptedException {
		//Launch chrome
		System.setProperty("webdriver.chrome.driver", "C:\\Projects\\Practise_Project\\Automation\\chromedriver.exe" );
		WebDriver wd = new ChromeDriver();
		//Navigate google
		wd.get("https://www.google.com/");
		Thread.sleep(5000);
		wd.manage().window().maximize();
	    //Extract Navigated URl
		System.out.println("URL:" +wd.getCurrentUrl());
		System.out.println("Title:" +wd.getTitle());
		//wd.close();
		wd.navigate().to("https://www.yahoo.com/");
		wd.navigate().back();
		Thread.sleep(5000);
		wd.navigate().forward();
		Thread.sleep(5000);
		wd.navigate().back();
		wd.navigate().refresh();
		wd.get("https://www.google.com/");
//		wd.close();
		Thread.sleep(5000);
		wd.findElement(By.name("q")).sendKeys("Selenium is good" +Keys.ENTER);
		List<WebElement> listElements =wd.findElements(By.xpath("//a/h3"));
		for(int i=0;i<listElements.size();i++) {
			System.out.println(listElements.get(i).getText());
//			listLinks.get(i).getAttribute("class")
		}
       /* for(WebElement eachElement:listLinks) {
			System.out.println(eachElement.getText());
//			listLinks.get(i).getAttribute("class")
		}*/
		Thread.sleep(5000);
		wd.close();
	}

}
